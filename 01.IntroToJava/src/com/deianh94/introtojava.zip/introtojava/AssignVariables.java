package com.deianh94.introtojava;

public class AssignVariables {

    public static void main(String[] args) {
	    boolean check = false;
        String address = "Palo Alto, CA";
        char c = 'c';
        short shortNum = 32767;
        int intNum = 2000000000;
        double doubleNum = 0.1234567891011;
        float floatNum = 0.5f;
        long longNum = 919827112351L;
        byte byteNum = 127;
        // short tooBigForShort = 32768;

        System.out.println(check);
        System.out.println(address);
        System.out.println(c);
        System.out.println(shortNum);
        System.out.println(intNum);
        System.out.println(doubleNum);
        System.out.println(floatNum);
        System.out.println(longNum);
        System.out.println(byteNum);
    }
}
